# F1M2BO Museum Online Quiz Javascript
F1M2BO  Museum Online Quiz Javascript



Demo: https://schw.hosts1.ma-cloud.nl/2020/quiz/  
Demo: https://schw.hosts1.ma-cloud.nl/2020/quiz/index1.html   
  
# Code Inleveren/gebruiken als onderdeel van de Beroepsopdracht    
Toepassen van de quiz in jouw Museum Online Beroepsopdracht

Maak eigen quizvragen
Laad eigen afbeelding(en)

Wijzig het eindscherm (site bezoeker kan een prijs winnen)  
Wijzig de kleurstelling van het CSS naar jouw eigen kleurenpalet  
Breid de code uit zodat quiz2 automatisch gestart wordt na quiz1, of laat gebruiker kiezen uit een quiz  


 
![screenshot](Screenshot.png)
