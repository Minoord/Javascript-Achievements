const quiz2 = 
{
    "quizID": "Math 1",
    "quizMetaData":
    {
        "title": "Math Trivia  1",
        "imageURI": "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/x3y3z3k-1568041112.jpg?crop=0.987xw:0.790xh;0.00160xw,0.128xh&resize=980:*"

    },
    "quizContent":		
		[
			{
				"question": "What is the next prime number after 7  ",
				"answers": [{
						"answer": "9",
						"feedback": false
					},
					{
						"answer": "10",
						"feedback": false
					},
					{
						"answer": "11",
						"feedback": true
					},
					{
						"answer": "13",
						"feedback": false
					}
				]
			},
			{
				"question": "65 - 43 =  ?",
				"answers": [{
						"answer": "12",
						"feedback": false
					},
					{
						"answer": "22",
						"feedback": true
					},
					{
						"answer": "32",
						"feedback": false
					}
				]
			},
			{
				"question": "Are the opposite angles of a parallelogram equal?",
				"answers": [{
						"answer": "no",
						"feedback": false
					},
					{
						"answer": "sometimes",
						"feedback": false
					},
					{
						"answer": "yes",
						"feedback": true
					}
				]
			}
		]
	}
