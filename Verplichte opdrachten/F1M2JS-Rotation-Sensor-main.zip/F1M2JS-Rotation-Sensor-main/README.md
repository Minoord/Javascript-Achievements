# F1M2JS-Rotation-Sensor   

[Demo https://schw.hosts1.ma-cloud.nl/2020/rotation/](https://schw.hosts1.ma-cloud.nl/2020/rotation/)  
